package com.janmat.janmat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JanmatApplicationTests {

	@Test
	void contextLoads() {
	}

}
