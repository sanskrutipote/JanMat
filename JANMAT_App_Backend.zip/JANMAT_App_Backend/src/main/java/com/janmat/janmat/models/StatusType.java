package com.janmat.janmat.models;

public enum StatusType {
    Planned,
    ongoing, 
    complted
}
