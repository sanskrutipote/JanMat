package com.janmat.janmat.Repository;

import com.janmat.janmat.models.PublicOpinion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublicOpinionRepository extends JpaRepository<PublicOpinion, Long> {
    
}

