//package com.janmat.janmat.Repository;
//
//import com.janmat.janmat.models.StatusType;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface StatusTypeRepository extends JpaRepository<StatusType, Long> {
//    
//}

