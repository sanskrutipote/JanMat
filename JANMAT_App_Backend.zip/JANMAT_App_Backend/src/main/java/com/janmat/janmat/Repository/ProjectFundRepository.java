package com.janmat.janmat.Repository;

import com.janmat.janmat.models.ProjectFund;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectFundRepository extends JpaRepository<ProjectFund, Long> {
    
}

